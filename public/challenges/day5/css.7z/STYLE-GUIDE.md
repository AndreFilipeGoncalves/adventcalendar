# Colors

- Background - #F3F3F3
- Title color - #A7A7A7
- Text color - #4E4E4E
- Text color, when completed - #C9CDD1

# Drop Shadow

```
filter: drop-shadow(0px 5.40459px 32.4276px #453F3F);
```

# Fonts

Nunito Sans - https://fonts.google.com/specimen/Nunito+Sans
