# Brief

In this project, we're creating a keyboard. I love this project because at first glance it seems easy, but there are some more complicated steps involved.

You can use as many (or as few) tools, libraries, and frameworks as you'd like. If you're trying to learn something new, this would be a great way to push yourself.

**Users should be able to:**

- See the keyboard centered on the page
- Whenever a user hovers over a specific key it will change colors
  - White keys will change to yellow `#ffd200`
  - Black keys will change to pink `#f40082`

