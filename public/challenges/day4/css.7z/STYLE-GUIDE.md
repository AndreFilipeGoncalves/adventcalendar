# Colors

- Keyboard Background Color - #F6F6F6
- Teal - #60C1B6
- Gray - #868888

# Fonts

- Inter - https://fonts.google.com/specimen/Inter
